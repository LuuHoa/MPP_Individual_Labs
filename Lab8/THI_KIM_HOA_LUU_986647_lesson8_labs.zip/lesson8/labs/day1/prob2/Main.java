package lesson8.labs.day1.prob2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {
	public static enum sortMethod {
		BYPRICE, BYTITLE
	};

	public static List<Product> list = new ArrayList<Product>();

	static {
		list.add(new Product("SSNote", 850.0, 9));
		list.add(new Product("SSNote", 700.0, 8));
		list.add(new Product("HPEnvy", 900.0, 1));
		list.add(new Product("HPSpec", 1600.0, 1));
		list.add(new Product("Iphone", 1100.0, 11));
		list.add(new Product("Iphone", 900.0, 10));

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		sortOriginal();
		sortByPrice();
		sortByTitle();
		sortClosure(sortMethod.BYPRICE);
		sortClosure(sortMethod.BYTITLE);
		sortLambda();

	}

	public static void sortOriginal() {
		System.out.println("Original List");
		System.out.println(list);
		System.out.println("");
	}

	public static void sortByPrice() {
		PriceComparator pc = new PriceComparator();
		Collections.sort(list, pc);
		System.out.println("A. Ordered List With Price");
		System.out.println(list);
		System.out.println("");
	}

	public static void sortByTitle() {
		TitleComparator tc = new TitleComparator();
		Collections.sort(list, tc);
		System.out.println("B. Ordered List With Title");
		System.out.println(list);
		System.out.println("");
	}

	public static void sortClosure(sortMethod method) {
		class ProductComparator implements Comparator<Product> {

			@Override
			public int compare(Product o1, Product o2) {
				if (method == sortMethod.BYPRICE)
					return Double.compare(o1.getPrice(), o2.getPrice());
				else
					return o1.getTitle().compareTo(o2.getTitle());
			}

		}
		Collections.sort(list, new ProductComparator());
		System.out.println("C. Ordered List With One Closured Comparator " + method);
		System.out.println(list);
		System.out.println("");
	}

	public static void sortLambda() {
		Collections.sort(list, (o1, o2) -> {
			int a = o1.getTitle().compareTo(o2.getTitle());
			if (a != 0)
				return a;
			else {
				return Integer.compare(o1.getModel(), o2.getModel());
			}
		});

		System.out.println("D. Ordered List With Lambda ");
		System.out.println(list);
	}

}
