package lesson8.labs.day2.prob3;

import java.util.Arrays;
import java.util.List;

public class Fruits {

	private static List<String> fruits;
	public static void main(String[] args) {
		fruits = Arrays.asList("Apple", "Banana","Orange","Cherries","blums");
		printByLambda();
		printByMethodReference();
	}
	
	public static void printByLambda()
	{
		System.out.println("3.1 Print By Lambda");
		fruits.forEach((x)->System.out.println(x));
	}
	
	public static void printByMethodReference()
	{
		System.out.println("3.2 Print By Method Reference");
		fruits.forEach(System.out::println);
	}

}
