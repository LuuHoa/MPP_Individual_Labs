package lesson8.labs.day2.prob4;

import java.util.Arrays;

public class Names {

	public static void main(String[] args) {
		String[] names = { "Alexis", "Tim", "Kyleen", "KRISTY" };
		System.out.println("Before: " + Arrays.asList(names).toString());
		Arrays.sort(names, String::compareToIgnoreCase);
		System.out.println("After sort ignoring case: " + Arrays.asList(names).toString());

	}

}
