package lesson8.labs.day2.prob1;

import java.util.function.Predicate;

public class MyClass {
	private int x;
	private int y;

	public MyClass(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public Boolean myMethod(MyClass cl) {
		Predicate<MyClass> pr = this::equals;
		return pr.test(cl);
	}

	public static void main(String[] args) {
		MyClass ob1 = new MyClass(1, 2);
		MyClass ob2 = new MyClass(1, 2);
		MyClass ob3 = new MyClass(3, 4);
		System.out.println("ob1 equals ob2: " + ob1.myMethod(ob2));
		System.out.println("ob1 equals ob3: " + ob1.myMethod(ob3));

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MyClass other = (MyClass) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}

}
