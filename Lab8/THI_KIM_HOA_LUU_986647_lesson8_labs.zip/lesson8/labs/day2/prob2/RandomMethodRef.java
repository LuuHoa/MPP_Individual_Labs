package lesson8.labs.day2.prob2;

import java.util.function.Supplier;

public class RandomMethodRef {

	public static void main(String[] args) {
		// Method Reference
		Supplier<Double> randomMR = Math::random;
		System.out.println("2.1 Generating by Method Reference");
		for (int i = 0; i < 5; i++)
			System.out.println("Random number " + i + " : " + randomMR.get());

		// Lambda
		Supplier<Double> randomLD = () -> Math.random();
		System.out.println("");
		System.out.println("2.2 Generating by Lambda");
		for (int i = 0; i < 5; i++)
			System.out.println("Random number " + i + " : " + randomLD.get());

		// Closure Inner Class
		class InnerRandomSupplier implements Supplier<Double> {
			@Override
			public Double get() {
				return Math.random();
			}

		}

		InnerRandomSupplier innerSupplier = new InnerRandomSupplier();
		System.out.println("");
		System.out.println("2.2 Generating by Closure Inner Class");
		for (int i = 0; i < 5; i++)
			System.out.println("Random number " + i + " : " + innerSupplier.get());

	}

}
