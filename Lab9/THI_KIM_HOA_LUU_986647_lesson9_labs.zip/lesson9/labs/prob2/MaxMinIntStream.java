package lesson9.labs.prob2;

import java.util.IntSummaryStatistics;
import java.util.stream.IntStream;


public class MaxMinIntStream {

	public static void main(String[] args) {
		IntStream myIntStream = IntStream.of(-7, -9, -11, 6, 15, 65);
		IntSummaryStatistics statistics = myIntStream.summaryStatistics();
		int min = statistics.getMin();
		int max = statistics.getMax();
		System.out.printf("Min is %d \n", min);
		System.out.printf("Min is %d", max);
	}
}
