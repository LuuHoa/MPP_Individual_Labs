package lesson9.labs.prob3;

@FunctionalInterface
public interface QuadFunction <S,T,U,M,R> {
	R apply(S s, T t, U u, M m);
}
