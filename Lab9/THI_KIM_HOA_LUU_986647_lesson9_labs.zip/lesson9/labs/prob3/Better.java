package lesson9.labs.prob3;

import java.util.List;
import java.util.function.Predicate;

public class Better {

	public static final TriFunction <Character, Character, Integer, Predicate<String>> pre = (c,d,len) -> s -> s.contains("" + c) && !s.contains("" + d) && s.length() == len;
	
	
	public int countWords(List<String> words, char c, char d, int len) {
		return (int) words.stream()
				          .filter(pre.apply(c, d, len))
				          .count();
	}
	
	public static void main(String[] args) {
		System.out.print(Folks.friends);
		Better g = new Better();
		System.out.println(" has " + g.countWords(Folks.friends, 'a', 'e', 4) + " meet the condition");
	}

}
