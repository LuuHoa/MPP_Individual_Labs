package lesson9.labs.prob3;

import java.util.List;

public class Good {

	public static void main(String[] args) {
		System.out.print(Folks.friends);
		Good g = new Good();
		System.out.println(" has " + g.countWords(Folks.friends, 'a', 'e', 4) + " meet the condition");
	}

	public int countWords(List<String> words, char c, char d, int len) {
		return (int) words.stream()
				          .filter(s -> s.contains("" + c) && !s.contains("" + d) && s.length() == len)
				          .count();

	}
}
