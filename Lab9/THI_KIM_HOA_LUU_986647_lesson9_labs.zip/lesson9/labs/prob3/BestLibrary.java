package lesson9.labs.prob3;

import java.util.List;

public class BestLibrary {

	public static final QuadFunction<List<String>, Character, Character, Integer, Integer> COUNT_MEET_CONDITION 
		= (l, c, d, len) ->  (int)l.stream()
			                       .filter(s -> s.contains("" + c) && !s.contains("" + d) && s.length() == len)
			                     //.filter(Better.pre.apply(c, d, len)) // Or can reuse this Predicate
			                       .count();
		     
   public static void main(String[] args) {
	   System.out.println(BestLibrary.COUNT_MEET_CONDITION.apply(Folks.friends, 'a', 'e', 4));
	   
   }
   
		     
}
