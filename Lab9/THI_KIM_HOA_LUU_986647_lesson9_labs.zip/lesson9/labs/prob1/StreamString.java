package lesson9.labs.prob1;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamString {

	public static void main(String[] args) {
		System.out.print(Stream.of("Bill", "Thomas", "Mary").collect(Collectors.joining(", ")));
	}

}
