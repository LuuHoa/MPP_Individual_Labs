package lesson9.labs.prob10;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Human {
	String name;
	int age;
	String gender;

	public Human(String name) {
		this.name = name;
	}

	public Human(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public Human(String name, int age, String gender) {
		this.name = name;
		this.age = age;
		this.gender = gender;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Human [name=" + name + ", age=" + age + ", gender=" + gender + "]";
	}
}

public class ConstructorReference {

	public static Stream<Human> getHumanStream(Human[] list) {
		return Arrays.asList(list).stream();
	}

	public static void main(String args[]) {
		Human[] list = { new Human("Joe", 35, "Male"), new Human("Jane", 45, "Female"), new Human("John", 30, "Male") };

		// Query 1 : Print only Female canditates names
		String st1 = getHumanStream(list).filter(p -> p.getGender().equalsIgnoreCase("Male")).map(p -> p.getName())
				.collect(Collectors.joining(", "));
		System.out.println("1. Female canditates names");
		System.out.println(st1);

		// Query 2 : Cretae an objecy by choosing suitable Interface to the specified
		// constructors(Totally 3 constuctors)using fouth type of Method Reference
		// ClassName::new. Then print the object status

		Function<String, Human> constructHuman1 = Human::new;
		BiFunction<String, Integer, Human> constructHuman2 = Human::new;
		TriFunction<String, Integer, String, Human> constructHuman3 = Human::new;

		Human h1 = constructHuman1.apply("Alice");
		System.out.println("2. Constructor1: " + h1.toString());

		Human h2 = constructHuman2.apply("Bob", 30);
		System.out.println("2. Constructor2: " + h2.toString());

		Human h3 = constructHuman3.apply("Carlos", 30, "Male");
		System.out.println("2. Constructor3: " + h3.toString());

		// Query 3 : Count the male candidates whose age is more than 30
		int cnt = (int) getHumanStream(list).filter(p -> p.getGender().equalsIgnoreCase("Male"))
				.filter(p -> p.getAge() > 30).count();
		System.out.println("3. Count the male candidates whose age is more than 30 is:" + cnt);
		System.out.println(cnt);

	}

}
