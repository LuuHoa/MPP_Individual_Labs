package lesson9.labs.prob6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BinaryOperator;

import jdk.nashorn.internal.ir.SetSplitState;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class UnionListSetString {

	public static void main(String[] args) {

		List<Set<String>> test = new ArrayList<>();
		test.add(new LinkedHashSet<String>(Arrays.asList("A", "B")));
		test.add(new LinkedHashSet<String>(Arrays.asList("D")));
		test.add(new LinkedHashSet<String>(Arrays.asList("1", "3", "5")));
		
		System.out.println("Before: " + test);
		System.out.println("After stream: " + union(test));

	}

	public static Set<String> union(List<Set<String>> sets) {
		
		Set<String> un = sets.stream()
				             .reduce(new LinkedHashSet<String>(), (set1, set2) -> {
																				Set<String> res = new  LinkedHashSet<>();
																				res.addAll(set1);
																				res.addAll(set2);
																				return res;
				             												});
		 return un;

	}

}
