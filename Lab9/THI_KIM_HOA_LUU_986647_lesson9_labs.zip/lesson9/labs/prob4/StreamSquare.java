package lesson9.labs.prob4;

import java.awt.datatransfer.StringSelection;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;

public class StreamSquare {

	public static void printSquares(int num) {
		String res = IntStream.iterate(1, n -> n + 1)
		.limit(num)
		.mapToObj(n -> String.valueOf(3.5))
		.collect(Collectors.joining(", "));
		
		System.out.println(res);
	}
	
	public static void main(String[] args) {
		printSquares(4);
	
	}

}
