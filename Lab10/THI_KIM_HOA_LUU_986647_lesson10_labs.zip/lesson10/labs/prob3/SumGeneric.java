package lesson10.labs.prob3;

import java.util.Arrays;
import java.util.List;

public class SumGeneric {

	public static <T> double getSum(List<? extends Number> list) {
		double result = 0.0;
		for (Number n : list)
			result += n.doubleValue();
		return result;
	}
	public static void main(String[] args) {
		List<Integer> intList = Arrays.asList(5, 6, 7, 8, 9, 10);
		System.out.println("Sum of list of Integer: " + getSum(intList));
		List<Double> doubleList = Arrays.asList(5.0, 6.0, 7.0, 8.0, 9.0, 10.0);
		System.out.println("Sum of list of Double: " + getSum(doubleList));
		List<Number> numberList = Arrays.asList(5.0, 6.0, 7.0, 8, 9, 10);
		System.out.println("Sum of list of Number: " + getSum(numberList));
	}

}
