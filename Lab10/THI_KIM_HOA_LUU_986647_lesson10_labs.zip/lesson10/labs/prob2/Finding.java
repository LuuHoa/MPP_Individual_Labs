package lesson10.labs.prob2;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class Finding<T> {

	public static <T extends Comparable<? super T>> T getSecondSmallest(List<T> list) {
	Optional<T> secondSmallest  = list.stream().distinct().sorted(T::compareTo).skip(1).findFirst();

	if(secondSmallest.isPresent())
		return secondSmallest.get()	;
	else 
		return null;
	}
	
	public static void main(String[] args) {
		
		List<Integer> intList = Arrays.asList(63, 75, 8, 96, -5);
		System.out.println("Second Smallest of list of Integer: " + getSecondSmallest(intList));
		
		List<Double> doubleList = Arrays.asList(-1.45, 22.67, 33.7, 5.5, 15.32, 96.4, 7.6);
		System.out.println("Second Smallest of list of Double: " + getSecondSmallest(doubleList));
		
		List<LocalDate> dateList = Arrays.asList(LocalDate.of(2011,02,26),LocalDate.of(2011,02,28),LocalDate.of(2018,02,26));
		System.out.println("Second Smallest of list of LocalDate: " + getSecondSmallest(dateList));
		
		List<String> strList = Arrays.asList("aa");
		System.out.println("Second Smallest of list of String: " + getSecondSmallest(strList));
		
		
	}

}
