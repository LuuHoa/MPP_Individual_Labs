package lesson7.labs.prob2;

public interface Polygon extends ClosedCurve {

	public double[] getSize();
	
	default public double computePerimeter() {
		double sum = 0.0;
		for (double i : getSize())
			sum += i;
		return sum;
	};
}
