package lesson7.labs.prob2;

public class EquilateralTriangle implements Polygon {
	private double edge;

	public EquilateralTriangle(double edge) {
		this.edge = edge;
	}

	@Override
	public double[] getSize() {
		double[] d = {this.edge,this.edge, this.edge};
		return d;
	}

	public double getEdge() {
		return edge;
	}

	public void setEdge(double edge) {
		this.edge = edge;
	}

	
}
