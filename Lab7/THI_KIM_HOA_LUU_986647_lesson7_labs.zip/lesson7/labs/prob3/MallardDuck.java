package lesson7.labs.prob3;

public class MallardDuck extends Duck {
	
	@Override
	public void display() {
		System.out.println("  display");
		
	}
	@Override
	public void fly() {
		this.flywithWings();
		
	}
	@Override
	public void quack() {
		this.quacking();
		
	}

}
