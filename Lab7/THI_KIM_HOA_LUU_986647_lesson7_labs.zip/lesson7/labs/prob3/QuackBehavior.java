package lesson7.labs.prob3;

public interface QuackBehavior {
	default public void quacking() {
		System.out.println("  quacking");
	}
	
	default public void muteQuack() {
		System.out.println("  cannot quack");
	}
	
	default public void squeak() {
		System.out.println("  squeaking");
	}
	
	public void quack();
}
