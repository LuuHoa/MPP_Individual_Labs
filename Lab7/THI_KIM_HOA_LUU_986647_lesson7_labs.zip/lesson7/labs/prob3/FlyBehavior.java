package lesson7.labs.prob3;

public interface FlyBehavior {
	default public void flywithWings() {
		System.out.println("  fly with wings");
	};
	
	default public void cannotFly() {
		System.out.println("  cannot fly");
	};
	
	public void fly();	
}
