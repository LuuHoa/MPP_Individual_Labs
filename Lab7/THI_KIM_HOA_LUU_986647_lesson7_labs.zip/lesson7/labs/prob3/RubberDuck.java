package lesson7.labs.prob3;

public class RubberDuck extends Duck {

	@Override
	public void display() {
		System.out.println("  displaying");
		
	}
	
	@Override
	public void fly() {
		this.cannotFly();
		
	}
	@Override
	public void quack() {
		this.squeak();
		
	}
}
